﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PReava
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e, int i)
        {
            double[] vetA = new double[16];
            double[] vetb = new double[16];
            String aux;
            for (int i = 0; i < vetA.Length; i++)
            {
                int v = i + 1;
                aux = base.Text.Insert($"Digite o {v}º número", "Entrada de dados");
                if (!decimal.TryParse(aux, out vetA[decimal]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }

            }
            Array.Reverse(vetA);
            aux = "";
            foreach (int i in vetA)
            {
                aux += i + "\n";
            }

            for (int i = 0; i < vetB.Length; i++)
            {
                aux = Text.Insert($"Digite o {i + 1}º número", "Entrada de dados");
                if (!int.TryParse(aux, out vetB[double]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            MessageBox.Show(aux);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox1.ClearSelected();
        }
    }
}
