﻿namespace Calculadora_IMC
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtAltura = new System.Windows.Forms.TextBox();
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.height = new System.Windows.Forms.Label();
            this.weight = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtResultadoIMC = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtAltura
            // 
            this.txtAltura.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.txtAltura.Location = new System.Drawing.Point(352, 91);
            this.txtAltura.Name = "txtAltura";
            this.txtAltura.Size = new System.Drawing.Size(100, 31);
            this.txtAltura.TabIndex = 0;
            // 
            // txtPeso
            // 
            this.txtPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.txtPeso.Location = new System.Drawing.Point(352, 141);
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(100, 31);
            this.txtPeso.TabIndex = 1;
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.height.Location = new System.Drawing.Point(272, 94);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(68, 25);
            this.height.TabIndex = 2;
            this.height.Text = "Altura";
            // 
            // weight
            // 
            this.weight.AutoSize = true;
            this.weight.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.weight.Location = new System.Drawing.Point(272, 141);
            this.weight.Name = "weight";
            this.weight.Size = new System.Drawing.Size(61, 25);
            this.weight.TabIndex = 3;
            this.weight.Text = "Peso";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label1.Location = new System.Drawing.Point(280, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "IMC";
            // 
            // txtResultadoIMC
            // 
            this.txtResultadoIMC.Enabled = false;
            this.txtResultadoIMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.txtResultadoIMC.Location = new System.Drawing.Point(352, 187);
            this.txtResultadoIMC.Name = "txtResultadoIMC";
            this.txtResultadoIMC.Size = new System.Drawing.Size(100, 31);
            this.txtResultadoIMC.TabIndex = 5;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnCalcular.Location = new System.Drawing.Point(214, 321);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(106, 46);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            // 
            // clear
            // 
            this.clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.clear.Location = new System.Drawing.Point(352, 321);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(106, 46);
            this.clear.TabIndex = 7;
            this.clear.Text = "Limpar";
            this.clear.UseVisualStyleBackColor = true;
            // 
            // exit
            // 
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.exit.Location = new System.Drawing.Point(492, 321);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(106, 46);
            this.exit.TabIndex = 8;
            this.exit.Text = "Sair";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtResultadoIMC);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.weight);
            this.Controls.Add(this.height);
            this.Controls.Add(this.txtPeso);
            this.Controls.Add(this.txtAltura);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAltura;
        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.Label weight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtResultadoIMC;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button exit;
    }
}

