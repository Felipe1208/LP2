﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVestibular
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            int[,] alunos = new int[6, 5];
            int alunosAno = 0;
            int totalAlunos = 0;

            for (int curso = 0; curso < 6; curso++
            {
                for(int ano = 0; ano < 5; ano++)
                {
                    alunosAno = Interaction.InputBox($"Digite núemro de alunos", "Digite o ano");
                    if (!double.TryParse(out alunos[curso, ano]) || alunos[curso, ano] < 0 || alunos[curso, ano] > 10)
                    { 
                        MessageBox.Show("Número de alunos sinválido!");
                    }

                    for(int )
                }
            }
        }
