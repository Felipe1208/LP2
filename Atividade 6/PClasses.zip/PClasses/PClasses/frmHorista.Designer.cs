﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstanciarMensalist = new System.Windows.Forms.Button();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lnlDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblNumeroHora = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstanciarMensalist
            // 
            this.btnInstanciarMensalist.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnInstanciarMensalist.Location = new System.Drawing.Point(266, 298);
            this.btnInstanciarMensalist.Name = "btnInstanciarMensalist";
            this.btnInstanciarMensalist.Size = new System.Drawing.Size(181, 83);
            this.btnInstanciarMensalist.TabIndex = 17;
            this.btnInstanciarMensalist.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalist.UseVisualStyleBackColor = true;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(337, 180);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntradaEmpresa.TabIndex = 16;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(246, 136);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioMensal.TabIndex = 15;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(175, 89);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(283, 20);
            this.txtNome.TabIndex = 14;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(198, 43);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 13;
            // 
            // lnlDataEntradaEmpresa
            // 
            this.lnlDataEntradaEmpresa.AutoSize = true;
            this.lnlDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lnlDataEntradaEmpresa.Location = new System.Drawing.Point(107, 175);
            this.lnlDataEntradaEmpresa.Name = "lnlDataEntradaEmpresa";
            this.lnlDataEntradaEmpresa.Size = new System.Drawing.Size(224, 24);
            this.lnlDataEntradaEmpresa.TabIndex = 12;
            this.lnlDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblSalarioMensal.Location = new System.Drawing.Point(107, 132);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(133, 24);
            this.lblSalarioMensal.TabIndex = 11;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblNome.Location = new System.Drawing.Point(107, 85);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(62, 24);
            this.lblNome.TabIndex = 10;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblMatricula.Location = new System.Drawing.Point(107, 38);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(85, 24);
            this.lblMatricula.TabIndex = 9;
            this.lblMatricula.Text = "Matrícula";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(204, 213);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 19;
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblDiasFalta.Location = new System.Drawing.Point(107, 213);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(91, 24);
            this.lblDiasFalta.TabIndex = 18;
            this.lblDiasFalta.Text = "Dias Falta";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(337, 260);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 21;
            // 
            // lblNumeroHora
            // 
            this.lblNumeroHora.AutoSize = true;
            this.lblNumeroHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblNumeroHora.Location = new System.Drawing.Point(107, 255);
            this.lblNumeroHora.Name = "lblNumeroHora";
            this.lblNumeroHora.Size = new System.Drawing.Size(125, 24);
            this.lblNumeroHora.TabIndex = 20;
            this.lblNumeroHora.Text = "Numero Hora";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.lblNumeroHora);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.btnInstanciarMensalist);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lnlDataEntradaEmpresa);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.Load += new System.EventHandler(this.frmHorista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstanciarMensalist;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lnlDataEntradaEmpresa;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblDiasFalta;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblNumeroHora;
    }
}