﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lnlDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioMensal = new System.Windows.Forms.TextBox();
            this.txtDataEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.btnInstanciarMensalist = new System.Windows.Forms.Button();
            this.btnInstanciarParam = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblMatricula.Location = new System.Drawing.Point(71, 29);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(85, 24);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblNome.Location = new System.Drawing.Point(71, 76);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(62, 24);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lblSalarioMensal.Location = new System.Drawing.Point(71, 123);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(133, 24);
            this.lblSalarioMensal.TabIndex = 2;
            this.lblSalarioMensal.Text = "Salário Mensal";
            // 
            // lnlDataEntradaEmpresa
            // 
            this.lnlDataEntradaEmpresa.AutoSize = true;
            this.lnlDataEntradaEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.lnlDataEntradaEmpresa.Location = new System.Drawing.Point(71, 166);
            this.lnlDataEntradaEmpresa.Name = "lnlDataEntradaEmpresa";
            this.lnlDataEntradaEmpresa.Size = new System.Drawing.Size(224, 24);
            this.lnlDataEntradaEmpresa.TabIndex = 3;
            this.lnlDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(162, 34);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 4;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(139, 80);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(283, 20);
            this.txtNome.TabIndex = 5;
            // 
            // txtSalarioMensal
            // 
            this.txtSalarioMensal.Location = new System.Drawing.Point(210, 127);
            this.txtSalarioMensal.Name = "txtSalarioMensal";
            this.txtSalarioMensal.Size = new System.Drawing.Size(100, 20);
            this.txtSalarioMensal.TabIndex = 6;
            // 
            // txtDataEntradaEmpresa
            // 
            this.txtDataEntradaEmpresa.Location = new System.Drawing.Point(301, 171);
            this.txtDataEntradaEmpresa.Name = "txtDataEntradaEmpresa";
            this.txtDataEntradaEmpresa.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntradaEmpresa.TabIndex = 7;
            // 
            // btnInstanciarMensalist
            // 
            this.btnInstanciarMensalist.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnInstanciarMensalist.Location = new System.Drawing.Point(230, 289);
            this.btnInstanciarMensalist.Name = "btnInstanciarMensalist";
            this.btnInstanciarMensalist.Size = new System.Drawing.Size(181, 83);
            this.btnInstanciarMensalist.TabIndex = 8;
            this.btnInstanciarMensalist.Text = "Instanciar Mensalista";
            this.btnInstanciarMensalist.UseVisualStyleBackColor = true;
            this.btnInstanciarMensalist.Click += new System.EventHandler(this.btnInstanciarMensalist_Click);
            // 
            // btnInstanciarParam
            // 
            this.btnInstanciarParam.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.btnInstanciarParam.Location = new System.Drawing.Point(428, 289);
            this.btnInstanciarParam.Name = "btnInstanciarParam";
            this.btnInstanciarParam.Size = new System.Drawing.Size(181, 83);
            this.btnInstanciarParam.TabIndex = 9;
            this.btnInstanciarParam.Text = "Instanciar Mensalista Passar Parâmetro";
            this.btnInstanciarParam.UseVisualStyleBackColor = true;
            this.btnInstanciarParam.Click += new System.EventHandler(this.btnInstanciarParam_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnInstanciarParam);
            this.Controls.Add(this.btnInstanciarMensalist);
            this.Controls.Add(this.txtDataEntradaEmpresa);
            this.Controls.Add(this.txtSalarioMensal);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lnlDataEntradaEmpresa);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lnlDataEntradaEmpresa;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioMensal;
        private System.Windows.Forms.TextBox txtDataEntradaEmpresa;
        private System.Windows.Forms.Button btnInstanciarMensalist;
        private System.Windows.Forms.Button btnInstanciarParam;
    }
}